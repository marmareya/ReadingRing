function [  ] = main_prog_noButton( vid)

  doRun=true;
   n=0; %to compare previous picture
   E1=0; E2=0; E3=0; %to say there is an error
   
%%%%%%%%%%%%%%%%%%%%%% snapshot + enahnce %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

    disp('taking snapshot')
    preview (vid)
   pause(3) %pause for 2.5 seconds
 closepreview;
 snapshot1 = getsnapshot(vid);
%    snapshot2 = imbinarize(snapshot1,'adaptive','ForegroundPolarity','dark','Sensitivity',0.4); %binarize to improve ocr
%   figure; imshowpair(snapshot1,snapshot2,'montage'); title('snapshot');
% snapshot2= rgb2gray(snapshot2);
%  se = strel('disk',12);
%  tophatFiltered = imtophat(snapshot2,se);
%  snapshot = imadjust(tophatFiltered); % imadjust to improve the visibility of the result.
% figure; imshow(snapshot1)
snapshot1=rgb2gray(snapshot1);

BW = im2bw(snapshot1,0.4);
[B,L] = bwboundaries(BW,'noholes');
snapshot=label2rgb(L, @jet, [.5 .5 .5]);
imshow(label2rgb(L, @jet, [.5 .5 .5]))
hold on
for k = 1:length(B)
   boundary = B{k};
   plot(boundary(:,2), boundary(:,1), 'w', 'LineWidth', 2)
end

%  [ snapshot] = segment_snap(snapshot1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%% OCR'ing %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while doRun % continue till error...if error take new snapshot
    
        n=n+1;


results = ocr(snapshot, 'TextLayout', 'Block'); %'Block' to instruct ocr to assume the image contains just one block of text.
% results = ocr(snapshot1,'CharacterSet', 'TextLayout','Block');
recognizedText2=results.Text 




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% checking errors %%%%%%%%%%%%%%%%%%%%%%%%

i = isempty(recognizedText2) ;%1 = empty
       if i==1
           system('say error no text detected please wait')
           disp('error no text detected')
   
                 return
       end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% if detectedtext is only space - error
p=isspace(recognizedText2); %1 = space 0 = not space
        if p == 1;
            system('say error no text detected please wait')
            disp('error no text detected')
           
    
                 return
        end
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% read one line %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      
newrecognizedText=textscan(recognizedText2,'%s',1,'Delimiter','\n'); %error if empty

% disp(newrecognizedText{1}) %View the contents of the cell
newrecognizedText=char(newrecognizedText{1}) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%should be alphabets or number and space after it
if ~isempty(newrecognizedText)
A = isstrprop(newrecognizedText, 'wspace') %1=white space
A= strfind(A,1) %loc of 1

else
    system('say error no text detected please wait')
            disp('error no text detected')
           
    
                 return
        
end

    if ~isempty(A)
%read till 1st space then check if digit or number
testrecognizedText= newrecognizedText(1:A(1)) %first letter till first spce
B = isstrprop(testrecognizedText,'alpha') %1=alphabets 
    
% compare if its 'A' otherwise no. 1 >1
tf = strcmp(testrecognizedText,'A'); %1=same
if tf ~= 1
B_find= strfind(B,1) 
%loc of 1 should be > 1 unless its 'a'
if length(B_find) == 1 %should be >1 
 B==0; %first word not a word
 E2=1 %error not a word

end
end

C = isstrprop(testrecognizedText,'digit') %1=numbers
        if isempty(C)
            E3=1; %no number
        end

    end

    
    
    
    if isempty(A)
    B = isstrprop(newrecognizedText,'alpha') %1=alphabets 
    
% compare if its 'A' otherwise no. 1 >1
tf = strcmp(newrecognizedText,'A'); %1=same
        if tf ~= 1
        B_find= strfind(B,1) 
        %loc of 1 should be > 1 unless its 'a'
        if length(B_find) == 1 %should be >1 
         B==0; %first word not a word
         E2=1 %error not a word
        end
        end
C = isstrprop(newrecognizedText,'digit') %1=numbers
        if isempty(C)
            E3=1; %no number
        end

    end
    
% secondlinei=textscan(recognizedText2,'%s',2,'Delimiter','\n'); %read two lines
%     secondline=char(secondlinei{1})
% 
%  %read from new line till end 
%  end_1line=length(newrecognizedText);
%  secondline(1:end_1line)=[]
% 
% if ~isempty(secondline)
%     
% A1 = isstrprop(secondline, 'wspace') %1=white space
% %read till 1st space then check if digit or number
% A1= strfind(A1,1) %loc of 1
% 
% testrecognizedText1= secondline(1:A1(1)) %first word till first spce
% 
% B1 = isstrprop(testrecognizedText1,'alpha') %1=alphabets 
% 
% % compare if its 'a' otherwise no. 1 >1
% tf1 = strcmp(testrecognizedText1,'A'); %1=same
% if tf1  ~= 1
% B1_find= strfind(B1,1) 
% %loc of 1 should be > 1 unless its 'a'
% if length(B1_find) < 1 %should be >1 
%  B1==0;
% end
% end
% 
% C1 = isstrprop(testrecognizedText1,'digit') %1=numbers
% end
% 
% 
% if (B==0 & C ==0) | isempty(newrecognizedText)
%     if B==0 & C ~=0 | ~isempty(secondline)
% %secondline is better then first line
%       system('say ur attepting to read the second line please point to the line above')
%         disp('error in reading correct line')
%         return
%     end; end


        

%if n=1 %first time   for i=1:end of line?? '\n'

%save2nd line for comparison only when read start of any line (how 2know??)
% secondlinei=textscan(recognizedText2,'%s',2,'Delimiter','\n') %read two line \
% secondline=char(secondlinei{1})
% whos secondline
% lll=length(secondline);
% secondline(2:lll-1)
% 
% compare_line=strcmp (secondline,newrecognizedText) % 1=same 0=not same

%if compare_line==1 
%error u went to the iner under
%return   
%end

% whos recognizedText2
% whos newrecognizedText
% % trysegment (snapshot)
% no_lines( snapshot )


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 if E1==1
     if E2==1
         if E3==1
      system('say error please wait ')
        disp('error no text detected')
        return
         end;end;end
 

 
 
%%%%%%%%%%%%%%%%%%%%%%%%% checking still %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

first_word = regexpi(newrecognizedText,'\w*') %1=word 
first_number = regexpi(newrecognizedText,'[0-9][0-9]');  %number followed by space or number
first_aA = regexpi(newrecognizedText,'[aA]\s'); %A folowed by space
first_space = regexpi(newrecognizedText,'\s[a-z]{21, }'); 

 B2 = isstrprop(newrecognizedText,'alpha') %1=alphabets 

    if ~isempty(first_word)
        if E2==1
                system('say error in detecting text please wait')
        disp('error no text detected1')
                return
            end;end;
        
       if ~isempty(first_word)
                if B2(1)~=1 %1=equal
                %first ch not a letter or number 
                 system('say error please wait ')
                disp('error no text detected2')
                return
             end;
       end
 
       
     
if isempty(first_space)
    if isempty(first_word) 
        if isempty(first_number)
            if isempty(first_aA)
                
      system('say error no text detected please wait ')
        disp('error no text detected3')
                 return

            end;end;end;end                   

if ~isempty(first_word) && first_word(1) > 1
    if ~isempty(first_number) && first_number(1) >1 
        if ~isempty(first_aA) && first_aA(1) > 1 
            if ~isempty(first_space)  && first_space(1) >  1
     system('say error in detecting text please wait')
                       disp('error in detecting text4')
                 return

            end;end;end;end

%%%%%%%%%%%%%%%%%%%%%%%%% dont read uncompleted words %%%%%%%%%%%%%%%%%%%%%%%
   
[recognizedText] = space( newrecognizedText);

% 
%   [L,D]=check(recognizedText(1)); %delete whats not a letter number
% 
%  
%               if isempty(L) && isempty(D)
%                   system('say error no text detected')
%                    disp('error no text detected')
%               return  
% 
%               end
            
              %replace recognize text by l or d which deleted anything not a
              %letter/number
              
              
%%%%%%%%%%%%%%%%%%%%%CHECK IF USER DIDNT MOVE FINGER YET%%%%%%%%%%%%%%%%%%
    if n >1
       %if recognizedText==previous
            c=strcmp(recognizedText,previous);
       if c==1 %same words
     system('say detected text is repeated, please move forward')
       disp('detected text is repeated, please move forward')
%         break

                 return
       end
    end
    

%%%%%%%%%%%%%%%%%%%another OCR method%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %  if isempty(recognizedText) 
   %[result2]= ocr_letter(snapshot);
   %recognizedText2 = result2.Text 
   % boxAroundText(recognizedText2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    
% %%%%%%%%%%%%%%%%%%USE DICTIONARY TO SPELL CHECL%%%%%%%%%%%%%%%%%%
%     
%     kkk = isspace(recognizedText) %1 = space 0 = not space if 0 one word 
%     kkk=find(kkk(1:end) == 1);
% 
% if kkk~=0
% %def of each word in recognizedText
% mm=length(kkk) +1 %number of spaces = number of words +1?
%  %define words m times
% 
% recognizedText_def=recognizedText(1:kkk(1)) %till first space %read one word at a time
% def = dict(recognizedText_def);
%    tfff= strcmp(def,'!ERROR: Definition not found.');
%    if tfff==1
%        system('say error please try again')
%        disp('Definition not found -> not a correctly spelled word.')
%        return
%    end
% 
%     if length(kkk)==1
% recognizedText_def=recognizedText(kkk(1):end)
% def = dict(recognizedText_def);
%    tfff= strcmp(def,'!ERROR: Definition not found.');
%    if tfff==1
%        system('say error please try again')
%        disp('Definition not found -> not a correctly spelled word.')
%        return
%    end
%     end
%     
%    if length(kkk)==2
% 
% tt=1
% for i=1:3
%     
% tt=tt+1;
%  
% recognizedText_def=recognizedText(kkk(1):kkk(tt))
% def = dict(recognizedText_def);
%    tfff= strcmp(def,'!ERROR: Definition not found.');
%    if tfff==1
%        system('say error please try again')
%        disp('Definition not found -> not a correctly spelled word.')
%        return
%    end
% end
%    end
% else
%    
%           %else one word
%  def = dict(recognizedText);
%  
%   
%    tfff= strcmp(def,'!ERROR: Definition not found.');
%    if tfff==1
%        system('say error please try again')
%        disp('Definition not found -> not a correctly spelled word.')
%        return
%    end
%    
% end
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% check if its a name %%%%%%%%%%%%%%%%%%

%google list of names then compare if not found in dictionary



%%%%%%%%%%%%%%%%%%%%%%%%%%%%DONE WITH CHECKING ERRORS%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%% show detected text %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    boxAroundText(recognizedText,snapshot1,results)

    
%%%%%%%remove repeated words from 'detected sentences'%%%%%%%%%%%%%%%%%%%

%if user didnt move right enough
%check start of text. if repeated word delete that part and read other text else error
%to move right 

Lia = ismember(recognizedText,previous); %Determine which elements of A are also in B. 1=repeated
first_0=find(Lia==0); %till first not the same word 0=not repeated

if isempty(first_0) %all words is repeated
     system('say Please move right')
       disp('next loop')
       return
else
    
    for l=1:first_0
        if lia(l)==1 
            recognizedText=recognizedText(l+1:end);
        end
    end

end


%%%%%%%%%%%%%%%%%%%%%%%%% SPEAK TEXT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    ocr_speak(recognizedText)
    
%%%%%%%%%%%%%%%%%%%%%%%%SAVE PREVIOUS TEXT%%%%%%%%%%%%%%%%%%%%%%%%%
  previous=recognizedText
 
%%%%%%%%%%%%%%%%%% IF WANT DEFINITION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%if
% call_dictionary( recognizedText )
%end

%%%%%%%%%%%%%%%%%% next loop  for screenshot %%%%%%%%%%%%

    system('say Please move right')
       disp('next loop')
       
end









end

