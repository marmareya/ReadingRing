function [  ] = def_prog(vid,z)
%english + one line



n=0; %to compare previous picture
E1=0; E2=0; E3=0; %to say there is an error


%%%%%%%%%%%%%%%%%%%%%% snapshot + enahnce %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

disp('taking snapshot')
    preview (vid)
    pause(2) %pause for 2 seconds
    closepreview;

    snapshot1 = getsnapshot(vid);
    snapshot1=rgb2gray(snapshot1);
    BW = im2bw(snapshot1,0.4);
    [B,L] = bwboundaries(BW,'noholes');
    snapshot=label2rgb(L, @jet, [.5 .5 .5]);

for k = 1:length(B)
    boundary = B{k};
% plot(boundary(:,2), boundary(:,1), 'w', 'LineWidth', 2)
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%% OCR'ing %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
doRun=true;

while doRun % continue till error...if error take new snapshot
    n=n+1;
    
results = ocr(snapshot, 'TextLayout', 'Block'); %'Block' to instruct ocr to assume the image contains just one block of text.
recognizedText2=results.Text 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% checking errors %%%%%%%%%%%%%%%%%%%%%%%%%%

    i = isempty(recognizedText2);%1 = empty
if i==1
    error=1; vibrate(error);
    disp('error no text detected (empty)')
    %system('say error no text detected please wait') %mac
    h = actxserver('SAPI.SpVoice');
    invoke(h,'speak','error no text detected please wait');
                 return
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% check if detectedtext contains only spaces
    p=isspace(recognizedText2); %1 = space 0 = not space
if p == 1;
    error=1;
    vibrate(error);
    %system('say error no text detected please wait') %mac
    disp('error no text detected (only contains space)')
	h = actxserver('SAPI.SpVoice');
	invoke(h,'speak','error no text detected please wait');
                 return
end
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% read one line %%%%%%%%%%%%%%%%%%%%%%%%%%%%
      
Text_1stLine=textscan(recognizedText2,'%s',1,'Delimiter','\n'); %text shuldnt be empty to do this line
Text_1stLine=char(Text_1stLine{1}) %first line only

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%first word should atleast be alphabets or number or " or ' 

if ~isempty(Text_1stLine) 
    %find space location to check first word 
    A = isstrprop(Text_1stLine, 'wspace'); %1=white space %find space loc
    A = strfind(A,1); %find 1's (loc of spaces)
else  %text is empty
    error=1; vibrate(error);
    disp('error no text detected (first line of txt is empty)')
    h = actxserver('SAPI.SpVoice');
    invoke(h,'speak','error no text detected please wait');
    return
end

if ~isempty(A) %there are spaces
    
%read till 1st space and check 
    text_till1stSpace= Text_1stLine(1:A(1)); %first word till first space
%check first word for letters 
    B = isstrprop(text_till1stSpace,'alpha'); %1=alphabets
    
if B~=0 %if text contains letters
    B_find= strfind(B,1); %find loc of 1's [loc of letters]
   
if length(B_find) == 1 %length of the loc of letters should be >1 unless its: I i a A
    one_letterWords = [ 'I' 'i' 'a' 'A']; %store 1 letter words
%check if word is contained in the list of one-letter-words.. else error
    c_1=strmatch(text_till1stSpace, one_letterWords,'exact'); %loc of it
if isempty(c_1)
    E2=1; %error not a word
end
end %length of text=1

else
    B=0; %first word not a word
end %check letter   

%check if containts number
     C = isstrprop(text_till1stSpace,'digit'); %1=numbers
if isempty(C)
       E3=1; %no number
end 
    
    CCh = isstrprop(text_till1stSpace, 'punct'); %1 = loc of punctuation (" ')
if isempty(CCh)
    %text doesnt contain punc ch.
    E1=1; %no punch ch
end

end %theres spaces


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if E1==1 %no punch ch  %and
if E2==1 %error not a word   %and
if E3==1 %no number  
    error=1;  vibrate(error);
    disp('error no text(Letter_#_PUNC) detected')
    h = actxserver('SAPI.SpVoice');
    invoke(h,'speak','error please wait');
        return
end;end;end
 
 
%%%%%%%%%%%%%%%%%%%%%%%%% checking still %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

first_word = regexpi(Text_1stLine,'\w*'); %1=word 
first_number = regexpi(Text_1stLine,'[0-9][0-9]');  %number followed by space or number
first_aA = regexpi(Text_1stLine,'[aA]\s'); %A folowed by space
first_space = regexpi(Text_1stLine,'\s[a-z]{21, }'); 

B2 = isstrprop(Text_1stLine,'alpha'); %1=alphabets 

if ~isempty(first_word)  %and
    if E2==1 %not a word
% system('say error in detecting text please wait')
	error=1;  vibrate(error);
	disp('error no text detected1')
	h = actxserver('SAPI.SpVoice');
	invoke(h,'speak','error in detecting text please wait');
                return
end;end;
        
if ~isempty(first_word)   %and
 if B2(1)~=1 %1=equal
%first ch not a letter or number 
    %system('say error please wait ')
	error=1; vibrate(error);  
	disp('error no text detected2')
	h = actxserver('SAPI.SpVoice');
	invoke(h,'speak','error please wait');
                return
end;end
 
if isempty(first_space)
    if isempty(first_word) 
        if isempty(first_number)
            if isempty(first_aA)
                
	error=1;  vibrate(error);     
	disp('error no text detected3')
	h = actxserver('SAPI.SpVoice');
	invoke(h,'speak','error no text detected please wait');
                 return
end;end;end;end                   

if ~isempty(first_word) && first_word(1) > 1
    if ~isempty(first_number) && first_number(1) >1 
        if ~isempty(first_aA) && first_aA(1) > 1 
            if ~isempty(first_space)  && first_space(1) >  1
	error=1;vibrate(error);     
	disp('error in detecting text4')
	h = actxserver('SAPI.SpVoice');
	invoke(h,'speak','error in detecting text please wait');
                 return
end;end;end;end

%%%%%%%%%%%%%%%%%%%%%%%%% dont read uncompleted words %%%%%%%%%%%%%%%%%%%%%
   
[recognizedText] = space(Text_1stLine);

%%%%%%%%%%%%%%%%%%%%%% read only  number/letters %%%%%%%%%%%%%%%%%%%%%%%%%%

     B2 = isstrprop(recognizedText,'alpha'); %1=alphabets
      C = isstrprop(recognizedText,'digit'); %1=numbers
      number_loc=find(C(1:end) == 1);
n1=number_loc(1);
nend=number_loc(end);
     letter_loc=find(B2(1:end) == 1);
     l1=letter_loc(1);
     lend=letter_loc(end);

if isempty(number_loc)
      recognizedTextnew = recognizedText(l1:lend);
end
if ~isempty(number_loc)
if  n1<l1 && nend>lend
    recognizedTextnew = recognizedText(n1:nend);
elseif n1>l1 && nend<lend
         recognizedTextnew = recognizedText(l1:lend);
elseif  n1>l1 && nend>lend
             recognizedTextnew = recognizedText(l1:nend);
    elseif  n1<l1 && nend<lend
         recognizedTextnew = recognizedText(n1:lend);
    
end
end

     
B2 = isstrprop(recognizedTextnew,'alpha'); %1=alphabets
      C = isstrprop(recognizedTextnew,'digit'); %1=numbers
R=B2+C;

     notletter_loc=find(R(1:end) == 0);
recognizedTextnew(notletter_loc) = ' ';

recognizedText=recognizedTextnew

              
%%%%%%%%%%%%%%%%%%%%%CHECK IF USER DIDNT MOVE FINGER YET%%%%%%%%%%%%%%%%%%%

if n >1 %(in second loop)
	c=strcmp(recognizedText,previous); %if recognizedText==previous=1
if c==1 %same words
    %system('say detected text is repeated, please move forward')
	error=1;  vibrate(error);
	disp('detected text is repeated, please move forward')
	h = actxserver('SAPI.SpVoice');
	invoke(h,'speak','detected text is repeated please move forward');
                 return
end %same words
end %n>1 (in second loop)


%%%%%%%%%%%%%%%%%%USE DICTIONARY TO SPELL CHECL%%%%%%%%%%%%%%%%%%
    
check_spaces = isspace(recognizedText); %1 = space 0 = not space if 0 one word 
locOF_spaces=find(check_spaces(1:end) == 1); %find loc of spaces

if ~isempty(locOF_spaces) %if theres spaces => more than 1 word 

%def of each word in recognizedText
    number_ofWords=length(locOF_spaces)+1;%number of spaces = number of words +1?
    
for mmm=1:number_ofWords
    
    recognizedText_def=recognizedText(1:locOF_spaces(mmm)); %read one word at a time
    def = dict(recognizedText_def);
	tfff= strcmp(def,'!ERROR: Definition not found.');
if tfff==1 %not found in dictionary
% check if its a name
    [list_names ] = list_of_names( );
    check_ifNAme=strmatch(recognizedText_def,list_names); %loc of list that matches where text
if isempty(list_names)
    error=1;  vibrate(error);
	disp('Definition not found -> not a correctly spelled word.')
	h = actxserver('SAPI.SpVoice');
	invoke(h,'speak','error please wait');
       return
end	
end %not in dictionary

end %for


else %else one word
    
	def = dict(recognizedText);
	tfff= strcmp(def,'!ERROR: Definition not found.');
    
if tfff==1 %not in dict
% check if its a name
    [list_names ] = list_of_names( );
    check_ifNAme=strmatch(recognizedText,list_names); %loc of list that matches where text
if isempty(list_names)
    error=1;  vibrate(error);
	disp('Definition not found -> not a correctly spelled word.')
	h = actxserver('SAPI.SpVoice');
	invoke(h,'speak','error please wait');
       return
end
   
end %not in dict

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%DONE WITH CHECKING ERRORS%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%% show detected text %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    boxAroundText(recognizedText,snapshot1,results)

    
%%%%%%%remove repeated words from 'detected sentences'%%%%%%%%%%%%%%%%%%%%%

%if user didnt move right enough
%check start of text. if repeated word delete that part and read other text
%else tell user to to move right if all is repeated but already chckd that

if n>1 %not 1st loop
    
%Determine which elements of text are also in previous.
    check_repeated = ismember(recognizedText,previous); %1=repeated 0=not repeated
    not_repeated=find(check_repeated==0); %loc of 0's (not repeated)
    
if isempty(not_repeated) %all words is repeated

	error=1; vibrate(error);
	h = actxserver('SAPI.SpVoice');
	invoke(h,'speak','error text is repeated, please move forward');
       return
else % theres words that rnt repeated  
%delete till 1st 0    
    loc_0=not_repeated(1); %loc of first not repeated word
    recognizedText=recognizedText(loc_0:end); %text after dete first repeated words
    
end 
end %not 1st loop

%%%%%%%%%%%%%%%%%%%%%%%%% SPEAK TEXT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    ocr_speak(recognizedText)
    
%%%%%%%%%%%%%%%%%%%%%%%%SAVE PREVIOUS TEXT%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  previous=recognizedText;
 
%%%%%%%%%%%%%%%%%% IF WANT DEFINITION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    
h = actxserver('SAPI.SpVoice');
invoke(h,'speak','if you ever want a definiton of the detected word please click the button once,or press the button 4 times to end the program');

%check if user wants to define word or end
button_value=fread(z) 
display(button_value)

switch button_value
    
case 49 %end
	call_dictionary(recognizedText)

case 52 %end
    button(z,button_value)
end
    
%%%%%%%%%%%%%%%%%% next loop  for screenshot %%%%%%%%%%%%

disp('next loop')
h = actxserver('SAPI.SpVoice');
invoke(h,'speak','detected text complete please continue reading');

       
end %while dorun

end %fn


