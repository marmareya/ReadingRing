function [c] = compare( n,recognizedText,previous )

%1st time  n = 1 or odd
    A=recognizedText;


c=5; %any number

%tf = strcmp(s1,s2)
%1 equal
%0 not equal

    %if mod(n,2) == 0 %number is even
%B=recognizedText;
 %end
    
  % if mod(n,2) ~= 0
    %number is odd
%A=recognizedText;
   end
   

    %compare
    c=strcmp(recognizedText,previous);
end   
  
            


