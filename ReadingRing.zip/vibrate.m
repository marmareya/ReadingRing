function [] = vibrate(error,z)

%%%%%%%%%%%%%%%%%%%%%%%%%%% ERROR %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% if error==1 %1st error
    
        %vibrate sequence
        fwrite(z,'a'); %vibrate
        pause(2);
        fwrite(z,'b'); %stop
        pause(2);
% end


end %fn
