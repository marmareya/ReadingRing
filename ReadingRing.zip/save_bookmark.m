function []=save_bookmark()


pageNumber=[]; %empty

h = actxserver('SAPI.SpVoice');
invoke(h,'speak','please point the camera to the bottom of the page while rising it 3 inches from the page');
    
vid.ROIPosition = [0 391 640 89];

    
  disp('taking snapshot')
    preview (vid)
   pause(3) %pause for 3 seconds
 closepreview;
 snapshot1 = getsnapshot(vid);
 snapshot1=rgb2gray(snapshot1);
BW = im2bw(snapshot1,0.4);
[B,L] = bwboundaries(BW,'noholes');
snapshot=label2rgb(L, @jet, [.5 .5 .5]);
% imshow(label2rgb(L, @jet, [.5 .5 .5]))
% hold on
for k = 1:length(B)
   boundary = B{k};
%    plot(boundary(:,2), boundary(:,1), 'w', 'LineWidth', 2)
end

results = ocr(snapshot, 'TextLayout', 'Block'); %'Block' to instruct ocr to assume the image contains just one block of text.
% results = ocr(snapshot1,'CharacterSet', 'TextLayout','Block');
recognizedText2=results.Text 

check_number = isstrprop(recognizedText2,'digit') %1=numbers

if isempty(check_number)
        h = actxserver('SAPI.SpVoice');
        invoke(h,'speak','Error please try pointing the camera in the right area');
        return
end


     notnumber=find(check_number(1:end) == 0);
recognizedText2(notnumber) = ' ';

    pageNumber=recognizedText2
   
 h = actxserver('SAPI.SpVoice');
 invoke(h,'speak','you are in page number');
    
 h = actxserver('SAPI.SpVoice');
invoke(h,'speak',pageNumber);

    

end

