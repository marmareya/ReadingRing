close all
clear all
clc


%camera input- image acq
%check
vid = videoinput('winvideo', 1, 'YUY2_640x480');
vid.ROIPosition = [4 358 631 105]; %W H
src = getselectedsource(vid);
vid.FramesPerTrigger = inf;
vid.ReturnedColorspace = 'rgb';
% edit resolution 
% src.Brightness = 255;
% src.Contrast = 127;
src.Sharpness = 3;
src.WhiteBalance = 4672;
src.Brightness = 136;
src.Contrast = 34;
src.Hue = -2;
src.Saturation = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%connect to vibration motor + Button

z=serial('COM13'); %device manager
set(z,'BaudRate',9600);
set(z,'Timeout',15); %timeout=time stops reading in sec
fopen(z);




doRunn=true;
     while doRunn
        main_prog(vid,z) 
     end %while
     
%when error--fclose(z) close all clear all


try
%%%%%%%%%%%%%%%%%%%%%%%%% Initalize ReadingRing %%%%%%%%%%%%%%%%%%%%%%%%%%%

h = actxserver('SAPI.SpVoice');
invoke(h,'speak','Welcome to Reading Ring, we hope you enjoy your reading');

h = actxserver('SAPI.SpVoice');
invoke(h,'speak','pleas note that If you would like to know the current date and time during your reading please press the button twice, and If you ever want to stop Reading-Ring please click the button 4 times');


button_value=fread(z) %read user input
display(button_value)
%takes 16 sec to reead

if ~isempty(button_value)
    
switch button_value
    
case 50 
	 button(z,button_value)
	disp('time')
    
case 52
	disp('end')
	[button_value] = button(z,button_value)	
end
end

    h = actxserver('SAPI.SpVoice');
    invoke(h,'speak','please listen carefully to the reading options');
    
    h = actxserver('SAPI.SpVoice');
    invoke(h,'speak','option 1: Read one line at a time. '); %scan word by word===1 click

    h = actxserver('SAPI.SpVoice');
    invoke(h,'speak','option 2: scan a whole page or a buisness car.'); %scan whole page===2 click

    h = actxserver('SAPI.SpVoice');
    invoke(h,'speak','option 3: Read and define words.'); %def===3 click
    h = actxserver('SAPI.SpVoice');z
    invoke(h,'speak','please click the button once for option 1. twice for option 2. or three times for option 3 now');

      h = actxserver('SAPI.SpVoice');
    invoke(h,'speak','option 4: to end and save a bookmark.'); %def===3 click
    h = actxserver('SAPI.SpVoice');z
    invoke(h,'speak','please click the button once for option 1. twice for option 2. or three times for option 3, and four times for option 4 now');

    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

button_value=fread(z) %read user input
display(button_value)

while isempty(button_value)
     h = actxserver('SAPI.SpVoice');
    invoke(h,'speak','please push the button');
    button_value=fread(z) %read user input
    display(fread(z))
end    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

switch button_value
    
case 49 %1
    
     
   
%%%%%
    
 doRunn=true;
     while doRunn
        main_prog(vid,z) 
     end %while

  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


case 50 %2
    
     while doRun
     ocr_wholePage(vid)
        button(z,button_value) %check if user wants to quit
     end %while
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

case 51 %3
    
     while doRun
        def_prog(vid,z)
        button(z,button_value) %check if user wants to quit
     end %while
     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     
case 52 %end
  
  button(z,button_value)	
  
end %switch

button_value=fread(z) %read user input
display(fread(z))
button(z,button_value) %check if user wants to quit/wants time

catch %incase of error

fclose(z);
close all
end %try

