function obj = DictService

obj.endpoint = 'http://services.aonaware.com/DictService/DictService.asmx';
obj.wsdl = 'http://services.aonaware.com/DictService/DictService.asmx?WSDL';

obj = class(obj,'DictService');

