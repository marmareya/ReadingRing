function  boxAroundText(recognizedText,snapshot,results)

%confidence
% text(600, 150, recognizedText, 'BackgroundColor', [1 1 1]);
% Iocr=insertObjectAnnotation(snapshot, 'rectangle',results.WordBoundingBoxes,results.WordConfidences);
% % figure; imshow(Iocr);
% % hold on
% % 
% % 
% 
% % Show the location of the word in the original image

Iname = insertObjectAnnotation(snapshot, 'rectangle', results.WordBoundingBoxes, results.Words);
% figure;
imshow(Iname);


% Find characters with low confidence
% lowConfidenceIdx = results.CharacterConfidences < 0.5
% figure(3); imshow(lowConfidenceIdx);
% %notify error of words with low conf
% 
% % Get the bounding box locations of the low confidence characters
% lowConfBBoxes = results.CharacterBoundingBoxes(lowConfidenceIdx, :);

% % Get confidence values
% lowConfVal = results.CharacterConfidences(lowConfidenceIdx);
% 
% % Annotate image with character confidences
% str = sprintf('confidence = %f', lowConfVal);
% Ilowconf = insertObjectAnnotation(snapshot, 'rectangle', lowConfBBoxes, str);
% figure(4); imshow(Ilowconf);

% % Sort the character confidences
% [sortedConf, sortedIndex] = sort(results.CharacterConfidences, 'descend');
% 
% % Keep indices associated with non-NaN confidences values
% indexesNaNsRemoved = sortedIndex( ~isnan(sortedConf) );
% figure(5); imshow(indexesNaNsRemoved);
% 
% roi=[1 1 599 150];
% text1 = deblank( {results.Text} ); %the |deblank| function is used to remove any trailing characters, such as white space or new lines.
% img  = insertObjectAnnotation(snapshot, 'rectangle',roi, text1);
% figure(6);  imshow(img)

end

