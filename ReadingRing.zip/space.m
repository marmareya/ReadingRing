function [recognizedText] = space( recognizedText )

%delete last word if theres no space after it

  %check= recognizedText(end)     % Extract the last element
 %cam detects 2 spaces after always 

spaces=isspace(recognizedText) %1 = space 0 = not space

if spaces == 0 %only one word
    return
end

    

l_1=length(spaces); %col
find_1 = find(spaces(1:end) == 1);    %not start at 0? check.
l_1=find_1(length(find_1)); %loc of last 1 in recognized text (1= space)
l_text=length(recognizedText);%l2= tot size of recogn
d=l_text-l_1; %number to replace by null



%skip first word, read word after space (1)


l_1=length(spaces); %col
%find_1 = find(spaces(1:end-2) == 1) cam detected 2 ones always 
find_1 = find(spaces(1:end) == 1);
l_1=find_1(1);%loc of first 1 in recognized text (1= space)
l_text=length(recognizedText);%l2= tot size of recogn



%new matrix will last element= space 
recognizedText(l_text-d:l_text)=[]  %d till last elements = null

% recognizedText(1:l_1)=[]  %first d elements = null if no space before


% check= recognizedText(end)     % Extract the last element
% p2=isspace(check)%1 = space 0 = not space

%recognizedText=    v(5:end)     % Extract the fifth through the last elements   


end

