function [] = ocr_wholePage(vid)

vid.ROIPosition = [0 0 640 480];
  doRun=true;
   n=0; %to compare previous picture
   E1=0; E2=0; E3=0; %to say there is an error
   
%%%%%%%%%%%%%%%%%%%%%% snapshot + enahnce %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

    disp('taking snapshot')
    preview (vid)
   pause(3) %pause for 2.5 seconds
 closepreview;
 snapshot1 = getsnapshot(vid);
snapshot1=rgb2gray(snapshot1);

BW = im2bw(snapshot1,0.4);
[B,L] = bwboundaries(BW,'noholes');
snapshot=label2rgb(L, @jet, [.5 .5 .5]);

for k = 1:length(B)
   boundary = B{k};
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%% OCR'ing %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while doRun % continue till error...if error take new snapshot
    
 n=n+1;


results = ocr(snapshot, 'TextLayout', 'Block'); %'Block' to instruct ocr to assume the image contains just one block of text.
% results = ocr(snapshot1,'CharacterSet', 'TextLayout','Block');
recognizedText2=results.Text 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% checking errors %%%%%%%%%%%%%%%%%%%%%%%%

i = isempty(recognizedText2) ;%1 = empty
       if i==1
                error=1;
            vibrate(error);
       disp('error no text detected')
%            system('say error no text detected please wait') %mac
           h = actxserver('SAPI.SpVoice');
            invoke(h,'speak','error no text detected please wait');
   
                 return
       end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% if detectedtext is only space - error
p=isspace(recognizedText2); %1 = space 0 = not space
        if p == 1;
            error=1;
            vibrate(error);
%             system('say error no text detected please wait') %mac
            disp('error no text detected')
                h = actxserver('SAPI.SpVoice');
            invoke(h,'speak','error no text detected please wait');
    
                 return
        end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% read only  number/letters %%%%%%%%%%%%%%%%%%%%%%%%%%

     B2 = isstrprop(recognizedText2,'alpha'); %1=alphabets
      C = isstrprop(recognizedText2,'digit'); %1=numbers
      number_loc=find(C(1:end) == 1);
n1=number_loc(1);
nend=number_loc(end);
     letter_loc=find(B2(1:end) == 1);
     l1=letter_loc(1);
     lend=letter_loc(end);

if isempty(number_loc)
      recognizedTextnew = recognizedText2(l1:lend);
end
if ~isempty(number_loc)
if  n1<l1 && nend>lend
    recognizedTextnew = recognizedText2(n1:nend);
elseif n1>l1 && nend<lend
         recognizedTextnew = recognizedText2(l1:lend);
elseif  n1>l1 && nend>lend
             recognizedTextnew = recognizedText2(l1:nend);
    elseif  n1<l1 && nend<lend
         recognizedTextnew = recognizedText2(n1:lend);
    
end
end

     
B2 = isstrprop(recognizedTextnew,'alpha'); %1=alphabets
      C = isstrprop(recognizedTextnew,'digit'); %1=numbers
R=B2+C;

     notletter_loc=find(R(1:end) == 0);
recognizedTextnew(notletter_loc) = ' ';

recognizedText2=recognizedTextnew



%%%%%%%%%%%%%%%%%%%another OCR method%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %  if isempty(recognizedText) 
   %[result2]= ocr_letter(snapshot);
   %recognizedText2 = result2.Text 
   % boxAroundText(recognizedText2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%DONE WITH CHECKING ERRORS%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%% show detected text %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    boxAroundText(recognizedText2,snapshot1,results)

    
%%%%%%% check if repeated page %%%%%%%%%%%%%%%%%%%

if n >1 %(in second loop)
	c=strcmp(recognizedText2,previous); %if recognizedText==previous=1
if c==1 %same words
    %system('say detected text is repeated, please move forward')
	error=1;  vibrate(error);
	disp('detected text is repeated, please move forward')
	h = actxserver('SAPI.SpVoice');
	invoke(h,'speak','detected text is repeated please go to the next page');
                 return
end %same words
end %n>1 (in second loop)


%%%%%%%%%%%%%%%%%%%%%%%%% SPEAK TEXT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    ocr_speak(recognizedText2)
    
%%%%%%%%%%%%%%%%%%%%%%%%SAVE PREVIOUS TEXT%%%%%%%%%%%%%%%%%%%%%%%%%
  previous=recognizedText2;
 

%%%%%%%%%%%%%%%%%% next loop  for screenshot %%%%%%%%%%%%

       disp('next loop')
            h = actxserver('SAPI.SpVoice');
            invoke(h,'speak','detected text complete please flip the page');
       

end
 
end

