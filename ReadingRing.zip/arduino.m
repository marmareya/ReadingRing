% function [] = vibrate(  )

z=serial('com13');
%vibrate
set(z,'BaudRate',9600);
fopen(z);
fwrite(z,'a'); %vibrate
pause(2);
fwrite(z,'b'); %stop
pause(2);

%button
aa= 1%fread(z)
while aa ~= 100
aa=fread(z)
display(fread(z))
end+



fclose(z)



%if z== 's' ;

%vibration 

% set(z,'BaudRate',115200);
% fopen(z);
% fwrite(z,'a');
% pause(2);
% 
% fwrite(z,'b');
% pause(2);
% fwrite(z,'a');
% pause(2);
% fwrite(z,'b');
% pause(2);
% fclose(z)
% %end

