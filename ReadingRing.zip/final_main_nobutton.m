close all
clear all
clc


%camera input- image acq
%vid = videoinput('winvideo', 2, 'YUY2_640x480');
%mac


vid = videoinput('macvideo', 1, 'YUY2_640x480');
% vid.ROIPosition = [1 1 599 150];
vid.ROIPosition = [0 0 600 300]; %W H
src.Brightness = 212;
src.Contrast = 115;
src.Brightness = 212;
src.Hue = 15;
src.Saturation = 104;
src.Sharpness = 6;


%need roi for big texts
% [vid]=vid_stabilize(vid);

src = getselectedsource(vid);
vid.FramesPerTrigger = inf;
%triggerconfig(vid, 'immediate');
vid.ReturnedColorspace = 'rgb';
preview (vid);

%stabilize vid


%%%%%%%%%%%%%%%%%%%button to start%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
preview (vid);
user_input = input('Enter y to run the program ', 's'); 
if user_input == 'y'
    closepreview;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%% Time + Date %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%if user wants to know the time + date (button)

%if 

    % t = datetime('now')

    %speak
    % h = actxserver('SAPI.SpVoice');
    % invoke(h,'speak',t);

%end
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%% initilize ReadingRing %%%%%%%%%%%%%%%%%%%%%%%%

%set stop watch- read till time is over. ask user if want to contine (reset
%stop watch) then read again- else close matlab -- how?

%if user wants to stop?? clear all close all !? - can just close laptop


for i=1:4 

 main_prog_noButton(vid) 

end %stop coding. (ocr+snap)
    
 
%%%%%%%%%%%%%%%%%%%%%%%%%%% COMMENTS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 %-cant read book title due to font
 

%vibrate when reach text. please move ur finger ftom top of the oage and
%moving right till first sentence is spotted (till vibration) then wait
%while it does ocr -- how!

%big text?  - need to change rio. how will blind knows its a big text tho?

%white.m - track white! good to track text after inverse!????????



 
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   

    
   
  
    
  

    
 



    

 

