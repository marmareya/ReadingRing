function [] = call_dictionary( recognizedText )

  k = isspace(recognizedText) %1 = space 0 = not space if 0 one word 
    k=find(k(1:end) == 1);

if k~=0 %more than a word

    mm=length(k) +1 %number of spaces = number of words +1?
 %define words m times

recognizedText_def=recognizedText(1:k(1)) %till first space 

system('say Please wait for the definition')
       disp('definition')
 def = dict(recognizedText_def)
 definition=def(15:250)
%check
 tf= strcmp(def,'!ERROR: Definition not found.');
   if tf==1
       system('say error please try again')
       disp('Definition not found -> not a correctly spelled word.')
       return
   end
    if isempty(definition)
       system('say Definition not found.')
       disp('Definition not found.')
    end
   

    if length(k)==1
        system('say Please wait for the definition of the next word')
       disp('definition')
recognizedText_def=recognizedText(k(1):end)
 def = dict(recognizedText_def)
 definition=def(15:250)
%check
 tf= strcmp(def,'!ERROR: Definition not found.');
   if tf==1
       system('say error please try again')
       disp('Definition not found -> not a correctly spelled word.')
       return
   end
    if isempty(definition)
       system('say Definition not found.')
       disp('Definition not found.')
    end
    end
    
   if length(k)==2
system('say Please wait for the definition of the three words')
       disp('definition')
t=1
for i=1:3
    
t=t+1;
 
recognizedText_def=recognizedText(k(1):k(t))
recognizedText_def=recognizedText(k(1):end)
 def = dict(recognizedText_def)
 definition=def(15:250)
%check
 tf= strcmp(def,'!ERROR: Definition not found.');
   if tf==1
       system('say error please try again')
       disp('Definition not found -> not a correctly spelled word.')
       return
   end
    if isempty(definition)
       system('say Definition not found.')
       disp('Definition not found.')
    end

end
   end
else           %else one word

   
system('say Please wait for the definition')
       disp('definition')
 def = dict(recognizedText);
 
  recognizedText_def=recognizedText(k(1):end)
 def = dict(recognizedText_def)
 definition=def(15:250)
%check
 tf= strcmp(def,'!ERROR: Definition not found.');
   if tf==1
       system('say error please try again')
       disp('Definition not found -> not a correctly spelled word.')
       return
   end
    if isempty(definition)
       system('say Definition not found.')
       disp('Definition not found.')
    end

   
   
end

end

