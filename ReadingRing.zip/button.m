function [] = button(z,button_value)

% try catch for error??  id error came. predict if smthn if error do recieve?
%         
%         1 click= 49  
%         2 clicks=50 time 
%         3 clicks=51 
%         4 clicks = 52 to end

if isempty(button_value)
    button_value=fread(z) %read user input
    display(fread(z))
end 

     
switch button_value
    case 50 %time
        h = actxserver('SAPI.SpVoice');
        invoke(h,'speak','the current time and date is');
    
         t = datetime('now')
         t=char(t);
     
         h = actxserver('SAPI.SpVoice');
         invoke(h,'speak',t);
    
    case 52 %end
   
	h = actxserver('SAPI.SpVoice');
    invoke(h,'speak','Do you want to save a bookmark of your current page? 1 click for yes.');
    
     button_value=fread(z) %read user input
    display(fread(z))
    
    if button_value==49 %1 click
        pageNumber=[];   
     while isempty(pageNumber)
            save_bookmark(); 
     end
    end
    
if isempty(button_value)
    h = actxserver('SAPI.SpVoice');
    invoke(h,'speak','Thank you for choosing Reading Ring, hope to see you soon');
    fclose(z) 
    close all
    clear all
end



end %case
        

end %fn

