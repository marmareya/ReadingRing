function [ output_args ] = no_lines( I )



%  img = rgb2gray(snapshot);
% [R, xp] = radon(img, [0 90]);
% figure; plot(xp,R(:,2)); title('at angle 90');
% r = R(:,2);
% r=r(92:391); % your image region
% blank = r < 3; % region without text
% [labeled, n] = bwlabel(blank);
% C = regionprops(labeled, 'Centroid'); % find the centers of blank regions
% for i=1:length(C)-1
%    figure; subplot(length(C)-1,1,i);
%    figure; imshow(img(C(i).Centroid(2):C(i+1).Centroid(2),:));     
% end



end

