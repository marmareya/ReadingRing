function [L,D] = check( text )
%check if letter or character

%isstrprop checks characters in a character array to see if they match a category you specify
%Test for alphabetic characters in a character vector:
%A = isstrprop('abc123def', 'alpha')
%A = 1 1 1 0 0 0 1 1 1

%Test for numeric digits in a character vector:
%A = isstrprop('abc123def', 'digit') 
%A =   0 0 0 1 1 1 0 0 0 
%A =   0 0 0 1 1 1 0 0 0

L = isstrprop(text, 'alpha')

%1=aplphabet
  
D = isstrprop(text, 'digit') 
   
%1= number
       
%isletter determines if a character is a letter



end

