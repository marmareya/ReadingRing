function [ output_args ] = findword( input_args )

%ex
%str = {'How much wood would a woodchuck chuck';
       
%idx = strfind(str,'wood');
%dx{:,:}
%ans = 10 23 ... The pattern wood occurs at indices 10 and 23


end

