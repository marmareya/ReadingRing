function def = dict(word)
%DICT Look up word definitions.
%Usage:
%   dict               [interactive GUI]
%   def = dict(word)   [like a function]
%
%Example:
%   dict
%   a = dict('computer')


%Based on the free dictionary web services at
%   http://services.aonaware.com/DictService/DictService.asmx


%    if nargin == 1, def = lookup(word); return; end
   
%   word='computer'; %to test
  
   def = lookup(word);
   
    
    % systemwide variable; preferences
    userhome = char(java.lang.System.getProperty('user.home'));
    filesep  = char(java.lang.System.getProperty('file.separator'));
    wordfn = [userhome filesep '.dict.word'];
    preffn = [userhome filesep '.dict.pref'];
    winpos = loadpref(preffn);
        
%     F = figure('MenuBar','none', 'Name','Online Dictionary', ...
%         'NumberTitle','off', 'WindowStyle', 'normal', ...
%         'Resize', 'off', 'Position', winpos);
% 
%     hlabel1 = uicontrol(F, 'Style', 'text', 'String', 'Look Up:', ...
%         'Position', [10,470,65,24]);
%     hlabel2 = uicontrol(F, 'Style', 'text', 'String', 'My Word List', ...
%         'Position', [460,470,80,24]);
%     htextfield = javacomponent(javax.swing.JTextField,[80,470,330,24], F);
%     textarea = javax.swing.JTextArea;
%     javacomponent(javax.swing.JScrollPane(textarea),[10,10,400,455], F);
%     
    %listarea = javax.swing.JList;
    %javacomponent(javax.swing.JScrollPane(listarea),[420,10,170,455], F);
%     
%     listbox = uicontrol(F, 'Style', 'listbox', 'Position', [420,40,170,425]);
%     button  = uicontrol(F, 'Style', 'pushbutton', 'String', 'Remove',...
%         'Position', [420,10,60,24]);

    %%% set GUI properties
%    set(hlabel1,    'Font', java.awt.Font('Times', java.awt.Font.PLAIN, 12));
%    set(hlabel2,    'Font', java.awt.Font('Times', java.awt.Font.PLAIN, 12));

%     set(htextfield, 'Font', java.awt.Font('Times', java.awt.Font.PLAIN, 12));
%     set(textarea,   'Font', java.awt.Font('Times', java.awt.Font.PLAIN, 12));

%     set(textarea, 'editable', 'off');

%     firstword = 'Type something and hit <enter>';
%     set(htextfield, 'Text', firstword);
%     select(htextfield);

    %%% Callbacks
%     set(F, 'CloseRequestFcn', {@savepref, {preffn, wordfn, listbox}});
    % set callbacks of the textfield
    
    % when <enter> is hit, find definitions
    
%     set(htextfield, 'ActionPerformedCallback', {@entered, {textarea, listbox}});
    
    % when clicked, highlight the text
%     set(htextfield, 'MouseClickedCallback', @clicked);
%     % when a list item is clicked, look it up
%     set(listbox, 'Callback', {@listselected, {htextfield,textarea}});
%     % when 'remove' is pressed ...
%     set(button, 'Callback', {@removepressed, listbox});

    %%% post GUI initialization
    %set(listbox, 'String', {'apple', 'disk'});
%     loadword(wordfn, listbox);
    
%Load Prefs
function z=loadpref(fn)
    try
        S = load(fn, 'winpos', '-MAT');
        z = S.winpos;
    catch
        % otherwise, default postion: screen center
        % disp('error opening pref file');
        winW = 600; winH = 500;
        ss = get(0, 'ScreenSize');
        scrnW = ss(3); scrnH = ss(4);
        z = [(scrnW-winW)/2,(scrnH-winH)/2,winW,winH];
    end
    

%Save Prefs
function savepref(f, evt, h)
    winpos = get(f, 'Position');
    save(h{1}, 'winpos', '-MAT');
    saveword(h{2}, h{3});
    delete(gcf);
    
%Load words into list
function loadword(fn, listbox)

    try
        S = load(fn, 'words', '-MAT');
        set(listbox, 'String', S.words);
    catch
    end

%Save words into file
function saveword(fn, listbox)
    words = get(listbox, 'String');
    save(fn, 'words', '-MAT');
    
%Insert word into list
function insertWord(word, listbox)
    words = get(listbox, 'String');
    
    %% chech if not duplicated
    if isempty(strmatch(word, words, 'exact')),
        words{end+1} = word;
        %% sort words cell array
        words = sort(words);
        %% put it back
        set(listbox, 'String', words);
        % find index
        i=strmatch(word, words, 'exact');
        % highlight it
        set(listbox, 'Value', i);
    end
    
    
%Callbacks
%looks up word definition, and prints it to the textarea
%highlights the entered word for fast new word entry
% function entered(hobj, eventdata, handles)
% 
%     word = get(hobj,'Text');
%     % filter the word. remove space, small cap
%     word = lower(strtrim(word));
%     
%     result = lookup(word)
%     setText(handles{1}, result);
%     select(hobj);
%     % update word list
%     if ~strcmpi(result(1:6), '!ERROR'),
%         insertWord(word, handles{2});
%     end

% list item selected
function listselected(hobj, evt, handles)
    words = get(hobj, 'String');
    if isempty(words), return; end
    word = words{get(hobj, 'Value')};
    
    result = lookup(word)
    setText(handles{1}, word);
    setText(handles{2}, result);
    select(handles{1});
    
%select text in the text field when clicked
function clicked(hobj, evt, handles)
    select(hobj);
    
% Remove Pressed
function removepressed(hobj, evt, h)
    words = get(h, 'String');
    if isempty(words), return; end
    words(get(h, 'Value'))=[];
    set(h,'String', words);
    if get(h,'Value')>length(get(h,'String')),
        set(h,'Value', length(get(h,'String')));
    end
    
%select text
function select(hobj)
    word = get(hobj,'Text');
    set(hobj, 'SelectionStart', 0, 'SelectionEnd', length(word));
    
%Given a word, returns definitions found from the internet services
%if null or error, return error message
function z=lookup(word)

    errorStr={
        '!ERROR: Definition not found.', 
        '!ERROR: Connection problem.'};
    try

        a=Define(DictService, word);
        
        z='';
        if isempty(a.Definitions), 
            z = errorStr{1};
        else
            ndef = length(a.Definitions.Definition);
            for i=1:ndef;
                def = a.Definitions.Definition(i).WordDefinition;
                dic = a.Definitions.Definition(i).Dictionary.Name;
                z = [z sprintf('%s\n# %s #\n\n',def,dic)];
            end
        end
    catch
        z = errorStr{2};
    end

    