function []=ocr_speak(recognizedText)

if  ~isempty(recognizedText)  %ifnotempty
 
%    %text to speech windows
h = actxserver('SAPI.SpVoice');
invoke(h,'speak',recognizedText);


else %empty
    
h = actxserver('SAPI.SpVoice');
invoke(h,'speak','sorry try again');

    %tts mac
  %system('say empty')

end


end

